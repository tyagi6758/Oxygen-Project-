insert into center (center_id,center_name,address,city,state,pincode)
	 values(
    center_seq.nextVal,
    'center1',
    'vijay nagar',
    'bhopal',
    'mp',
    '999888'
    
); 
insert into cylinder (id,price_per_cylinder,quantity,type,weight,center_id)
	 values(
    cylinder_seq.nextVal,
    
    15000,
    100,
    'medium',
    15,
    1
    
); 
insert into USER_INFO (id,age,contact_number,gender,email,name,password,role)
	 values(
    user_id_seq.nextVal,
    23
    9998884443,
    'female',
    'zynna@gmail.com',
    'zynna',
    'zynna123',
    'USER'
     insert into center (center_id,center_name,address,city,state,pincode)
	 values(
    center_seq.nextVal,
    'center1',
    'vijay nagar',
    'bhopal',
    'mp',
    '999888'
    
); 
insert into cylinder (id,price_per_cylinder,quantity,type,weight,center_id)
	 values(
    cylinder_seq.nextVal,
    
    15000,
    100,
    'medium',
    15,
    1
    
); 
insert into USER_INFO (id,age,contact_number,gender,email,name,password,role)
	 values(
    user_id_seq.nextVal,
    23
    9998884443,
    'female',
    'zynna@gmail.com',
    'zynna',
    'zynna123',
    'USER'
     
); 

insert into USER_INFO (id,age,contact_number,gender,email,name,password,role)
	 values(
    user_id_seq.nextVal,
    25
    9998884444,
    'female',
    'admin@gmail.com',
    'Admin',
    'admin123',
    'ADMIN'
     
);
); 

insert into USER_INFO (id,age,contact_number,gender,email,name,password,role)
	 values(
    user_id_seq.nextVal,
    25
    9998884444,
    'female',
    'admin@gmail.com',
    'Admin',
    'admin123',
    'ADMIN'
     
);