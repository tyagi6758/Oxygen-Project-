package com.herostudio.oxygenmanagementsystem.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Book")
public class BookCylinder {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int bookId;

    @Column(name = "user_id")
    private int userId;

    @Column(name = "cylinder_id")
    private int cylinderId;

    public BookCylinder() {
    }

    public BookCylinder(int userId, int cylinderId) {
        this.userId = userId;
        this.cylinderId = cylinderId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getCylinderId() {
        return cylinderId;
    }

    public void setCylinderId(int cylinderId) {
        this.cylinderId = cylinderId;
    }
}
