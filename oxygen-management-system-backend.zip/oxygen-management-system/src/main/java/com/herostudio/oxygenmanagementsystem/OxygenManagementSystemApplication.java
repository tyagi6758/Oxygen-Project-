package com.herostudio.oxygenmanagementsystem;

import com.herostudio.oxygenmanagementsystem.model.Center;
import com.herostudio.oxygenmanagementsystem.model.Cylinder;

import com.herostudio.oxygenmanagementsystem.service.CenterService;
import com.herostudio.oxygenmanagementsystem.service.CylinderService;
//import com.herostudio.oxygenmanagementsystem.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class OxygenManagementSystemApplication  {

	public static void main(String[] args) {
		SpringApplication.run(OxygenManagementSystemApplication.class, args);
	}
	
	
	
}
