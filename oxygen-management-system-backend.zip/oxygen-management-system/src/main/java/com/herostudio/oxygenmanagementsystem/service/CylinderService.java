package com.herostudio.oxygenmanagementsystem.service;

import com.herostudio.oxygenmanagementsystem.exception.NullObjectException;
import com.herostudio.oxygenmanagementsystem.model.Center;
import com.herostudio.oxygenmanagementsystem.model.Cylinder;
import com.herostudio.oxygenmanagementsystem.repository.CylinderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CylinderService {
    @Autowired
    private CylinderRepo cylinderRepo;
    @Autowired
    private CenterService centerService;

    public Optional<Cylinder> getById(int id){
        return cylinderRepo.findById(id);
    }
    public List<Cylinder> getAll(){
        return cylinderRepo.findAll();
    }
    public List<Cylinder> getAll(int id){
        Center center = null;
        if(centerService.getById(id).isPresent()) {
           center = centerService.getById(id).get();
        } else {
            throw new NullObjectException("Center not found");
        }
        return cylinderRepo.findByCenter(center);
    }

    public Cylinder add(Cylinder cylinder, int id) {
        Center center = null;
        if (centerService.getById(id).isPresent()){
            center = centerService.getById(id).get();
            cylinder.setCenter(center);
            return cylinderRepo.save(cylinder);
        } else {
            throw new NullObjectException("Center not found!");
        }

    }

    public Cylinder editCylinder(Cylinder cylinder, int id) {
        Center center = null;
        if (centerService.getById(id).isPresent()){
            center = centerService.getById(id).get();
        }
        cylinder.setCenter(center);
        return cylinderRepo.save(cylinder);
    }

    public void deleteCylinder(int centerId, int id) {
        if (!centerService.getById(centerId).isPresent()){
            throw new NullObjectException("Center not found!");
        }
        cylinderRepo.deleteById(id);
    }

    public List<Cylinder> getByCity(String city) {
        List<Center> centers = centerService.getByCity(city);
        List<Cylinder> cylinders = new ArrayList<>();
        for(Center center : centers){
            cylinders.addAll(center.getCylinders());
        }
        return cylinders;
    }
}
