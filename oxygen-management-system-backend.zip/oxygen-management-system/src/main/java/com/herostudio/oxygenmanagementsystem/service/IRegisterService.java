package com.herostudio.oxygenmanagementsystem.service;

import com.herostudio.oxygenmanagementsystem.model.User;
import com.herostudio.oxygenmanagementsystem.model.UserList;

public interface IRegisterService {

User registerUser(User user);
	
	User getUser(Integer userId);
	
	UserList getAllUsers();
	
	User loginUser(String userName,String userPassword); 
	
	boolean removeAllUsers();
	
	boolean removeUserById(Integer userId);
}
