package com.herostudio.oxygenmanagementsystem.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;

@Entity
public class Cylinder {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "cylinder_seq")
    @Column(name = "id")
    private int id;

    @Column(name = "type")
    private String type;
    @Column(name = "weight")
    private int weight;
    @Column(name = "quantity")
    private int quantity;
    @Column(name = "pricePerCylinder")
    private int pricePerCylinder;

    @ManyToOne//(cascade = CascadeType.ALL)
    @JoinColumn(name = "CenterId")
    @JsonIgnoreProperties("cylinders")
    private Center center;

    public Cylinder() {
    }

    public Cylinder(String type, int weight, int quantity, int pricePerCylinder) {
        this.type = type;
        this.weight = weight;
        this.quantity = quantity;
        this.pricePerCylinder = pricePerCylinder;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPricePerCylinder() {
        return pricePerCylinder;
    }

    public void setPricePerCylinder(int pricePerCylinder) {
        this.pricePerCylinder = pricePerCylinder;
    }

    public Center getCenter() {
        return center;
    }

    public void setCenter(Center center) {
        this.center = center;
    }

    @Override
    public String toString() {
        return "Cylinder{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", weight=" + weight +
                ", quantity=" + quantity +
                ", pricePerCylinder=" + pricePerCylinder +
                ", center=" + center +
                '}';
    }
}
