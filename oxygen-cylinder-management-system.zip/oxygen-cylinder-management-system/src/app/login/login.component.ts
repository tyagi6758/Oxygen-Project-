import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../register/user';

import { AuthService } from '../shared/auth.service';
import { UserService } from '../user.service';
import { Login } from './login';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user=new User();
  redirect:boolean=false;
  constructor(private service:UserService,private route:Router) { }

  ngOnInit(): void {
  }
  onClickSubmit(form)
  {
    this.service.loginUser(this.user).subscribe(
       (success)=>{
         alert(success.userRole+" Login Successfully")
        
         if(success.userRole=="ADMIN")
         {
           this.route.navigate(['/adminhome'])
         }
         else
         {
          
           this.route.navigate(['/userhome'])
         }
         
       },
       (error)=>{
          alert("Invalid UserName or Password");
       }

    )
  }

  signUp()
  {
    
    this.route.navigate(['/register'])
  }
  
}
    
