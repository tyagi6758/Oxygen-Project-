export class Login {
    constructor(
        // public id: number,
        public userName: string,
        public password: string,
        // public userRole: string,
    ){}
}
