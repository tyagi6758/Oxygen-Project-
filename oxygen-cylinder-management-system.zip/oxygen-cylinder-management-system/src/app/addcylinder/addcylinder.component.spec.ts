import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddcylinderComponent } from './addcylinder.component';

describe('AddcylinderComponent', () => {
  let component: AddcylinderComponent;
  let fixture: ComponentFixture<AddcylinderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddcylinderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddcylinderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
