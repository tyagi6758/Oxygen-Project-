import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CenterService } from '../addcenter/Center.service';


@Component({
  selector: 'app-deletecenter',
  templateUrl: './deletecenter.component.html',
  styleUrls: ['./deletecenter.component.css']
})
export class DeletecenterComponent implements OnInit {

  message: String = "";

  constructor(private service: CenterService, private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    let centerId: number = 0;  
alert("Delete Center...");
    this.activatedRoute.params.subscribe(data => {
      centerId = data.id;
      console.log(centerId);
      this.service.deleteCenter(centerId).subscribe(response => {
        console.log(response);
        let isDeleted: boolean = response;
        console.log(isDeleted);
        if(isDeleted) {
          this.message = "center deleted successfully!!!";
        } else {
          this.message = "Unknown error occured";
        }
        
        this.router.navigateByUrl("/viewallcenter");
      });
    });  

}
}
