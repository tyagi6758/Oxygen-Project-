import { Cylinderconsignment } from './cylinderconsignment';

describe('Cylinderconsignment', () => {
  it('should create an instance', () => {
    expect(new Cylinderconsignment()).toBeTruthy();
  });
});
