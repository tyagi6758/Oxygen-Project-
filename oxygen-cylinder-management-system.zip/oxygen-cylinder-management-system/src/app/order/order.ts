import { Cylinderconsignment } from "../cylinderconsignment";
import { Login } from "../login/login";

export class Order {
    
        constructor(
            public id: number,
            public login:Login,
            public cylinder: Cylinderconsignment,
           
            
        ){}
}
