import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CylinderdataComponent } from './cylinderdata.component';

describe('CylinderdataComponent', () => {
  let component: CylinderdataComponent;
  let fixture: ComponentFixture<CylinderdataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CylinderdataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CylinderdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
