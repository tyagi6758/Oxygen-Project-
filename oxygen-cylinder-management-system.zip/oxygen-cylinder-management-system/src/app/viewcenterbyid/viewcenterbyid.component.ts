import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';


@Component({
  selector: 'app-viewcenterbyid',
  templateUrl: './viewcenterbyid.component.html',
  styleUrls: ['./viewcenterbyid.component.css']
})
export class ViewcenterbyidComponent implements OnInit {

  title="view Now";
public viewcenterbyidForm:FormGroup;

msg:string='';
success:boolean=false;
redirect:boolean=false;
  constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit() :void {
    this.viewcenterbyidForm=new FormGroup({
    //  centerid: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
      
    });
  }

  addingcenter(){
    console.warn(this.viewcenterbyidForm.value);
  }  
  // get centerid(){
  //   return this.viewcenterbyidForm.get('cylinderid');
  // }
 
  
  onSubmit() {
    this.route.navigate(["/viewallcenter"]);
  


}
}
