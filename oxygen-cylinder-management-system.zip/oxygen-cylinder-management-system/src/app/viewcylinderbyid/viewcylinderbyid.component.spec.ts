import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcylinderbyidComponent } from './viewcylinderbyid.component';

describe('ViewcylinderbyidComponent', () => {
  let component: ViewcylinderbyidComponent;
  let fixture: ComponentFixture<ViewcylinderbyidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewcylinderbyidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewcylinderbyidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
