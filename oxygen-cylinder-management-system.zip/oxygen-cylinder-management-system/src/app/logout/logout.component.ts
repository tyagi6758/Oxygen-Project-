import { Component, OnInit } from '@angular/core';
import { AuthService } from '../shared/auth.service';
import { Router,ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  token: string;
  constructor(private authservice : AuthService,private router: Router,private http: HttpClient) { 
    const user = JSON.parse(localStorage.getItem('eq_user'));
    if (user) {
      this.token = user.access_token;
    }
  }
 
 
  ngOnInit() {
  }


   logout() {
  //   this.token = null;
  //   localStorage.removeItem('eq_user');
  //   localStorage.clear();
  //   this.authservice.logout().subscribe( s => {
  //       this.router.navigate(['login']);
  //  });
  this.authservice.logout();
  }
   
}
