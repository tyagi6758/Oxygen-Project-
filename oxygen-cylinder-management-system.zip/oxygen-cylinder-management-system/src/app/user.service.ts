import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from './login/login';
import { User } from './register/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  
  baseUrl:string="http://localhost:9090/";
   
  getData() {
    return this.http.get("../assets/slideData.json")
  }
   
  public loginUser(user:Login):Observable<User>
  {
    console.log(user);
    return this.http.post<User>(this.baseUrl+"login",user);
  } 

  public registerUser(user:User):Observable<User>
  {
    console.log(this.baseUrl+"register");
    return this.http.post<User>(this.baseUrl+"register",user);
  }
}
