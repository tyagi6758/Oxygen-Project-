import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import {ReactiveFormsModule } from '@angular/forms';

import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AppRoutingModule } from './app-routing.module'; 
import { AuthGuard } from './shared/auth.guard';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { CylinderCartComponent } from './cylinder-cart/cylinder-cart.component';
import { HeaderComponent } from './header/header.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
// import { AddUserComponent } from './register/add-user/add-user.component';
import { OrderComponent } from './order/order.component';
import { CylinderdataComponent } from './cylinderdata/cylinderdata.component';
import { AddcenterComponent } from './addcenter/addcenter.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { ViewallcenterComponent } from './viewallcenter/viewallcenter.component';
import { ViewallcylinderComponent } from './viewallcylinder/viewallcylinder.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { OrdercylinderComponent } from './ordercylinder/ordercylinder.component';
import { UpdatecenterComponent } from './updatecenter/updatecenter.component';
import { UpdatecylinderComponent } from './updatecylinder/updatecylinder.component';
import { ViewcenterbyidComponent } from './viewcenterbyid/viewcenterbyid.component';
import { ViewcylinderbyidComponent } from './viewcylinderbyid/viewcylinderbyid.component';
import { HeadertwoComponent } from './headertwo/headertwo.component';
import { ViewcylinderbycityComponent } from './viewcylinderbycity/viewcylinderbycity.component';
import { UserviewcylinderbyidComponent } from './userviewcylinderbyid/userviewcylinderbyid.component';
import { AddcylinderComponent } from './addcylinder/addcylinder.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { DeletecenterComponent } from './deletecenter/deletecenter.component';
import { DeletecylinderComponent } from './deletecylinder/deletecylinder.component';



@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HomeComponent,
    LoginComponent,
    LogoutComponent,
    CylinderCartComponent,
    HeaderComponent,
    ViewBookingComponent,
    // AddUserComponent,
    OrderComponent,
    CylinderdataComponent,
    AddcenterComponent,
    AdminhomeComponent,
    ViewallcenterComponent,
    ViewallcylinderComponent,
    UserhomeComponent,
    OrdercylinderComponent,
    UpdatecenterComponent,
    UpdatecylinderComponent,
    ViewcenterbyidComponent,
    ViewcylinderbyidComponent,
    HeadertwoComponent,
    ViewcylinderbycityComponent,
    UserviewcylinderbyidComponent,
    AddcylinderComponent,
    DeletecenterComponent,
    DeletecylinderComponent

    
 
    
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    AppRoutingModule
  ],
  exports: [RouterModule],
 
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
