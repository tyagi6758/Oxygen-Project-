export class Center {
    constructor(
        public centerId: number,
        public centerName: string,
        public address: string,
        public city: string,
        public state: string,
        public pinCode: string,
        
       
        
    ){}
}
