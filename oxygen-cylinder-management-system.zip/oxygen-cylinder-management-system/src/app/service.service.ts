import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http:HttpClient) { }
  
  baseUrl:string="http://localhost:9191/";
   
  getData() {
    return this.http.get("../assets/slideData.json")
  }
   
//   public loginUser(user:User):Observable<User>
//   {
//     console.log(this.baseUrl+"login");
//     return this.http.post<User>(this.baseUrl+"login",user);
//   } 

//   public registerUser(user:User):Observable<any>
//   {
//     console.log(this.baseUrl+"register");
//     return this.http.post<User>(this.baseUrl+"register",user);
//   } 
 }