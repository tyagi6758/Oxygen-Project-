import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';
import { UserService } from '../user.service';
import { User } from './user';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers:[AuthService]
})
export class RegisterComponent implements OnInit {
  isSelected:string="USER";
  constructor(private service:UserService,private router:Router) { }
  sliderArray: object[];
  
  ngOnInit() {
  
  }
  onClickSubmit(user)
  {
  
    this.service.registerUser(user).subscribe(
      (success)=>{
        alert("User Successfully Added");
        this.router.navigate(['/login'])
      },
      (error)=>{
         alert("User Name or Email or Number Already Exist");
      }
    ) 
  }
  login()
  {
    
    this.router.navigate(['/login'])
  }
  
}
