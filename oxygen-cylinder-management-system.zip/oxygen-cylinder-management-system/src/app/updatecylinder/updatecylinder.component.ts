import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CylinderService } from '../addcylinder/Cylinder.service';
import { Center } from '../center';
import { Cylinderconsignment } from '../cylinderconsignment';
import { AuthService } from '../shared/auth.service';


@Component({
  selector: 'app-updatecylinder',
  templateUrl: './updatecylinder.component.html',
  styleUrls: ['./updatecylinder.component.css']
})
export class UpdatecylinderComponent implements OnInit {

  public updatecylinder:FormGroup;
  message: string = '';
  success: boolean = false;
  centers: Center[] = [];
  // update: Cylinderconsignment[] = [];
  // centers=new Center();
  cylinder: Cylinderconsignment= new Cylinderconsignment(0,0,0,'',0,new Center(0,'','','','',''));

  constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute,private cylindersevice:CylinderService) { }

  ngOnInit() :void {
    this.updatecylinder=new FormGroup({
    
      type: new FormControl(''),
      center: new FormControl(''),
      weight: new FormControl(''),
      quantity: new FormControl(''),
      pricePerCylinder: new FormControl(''),
     
    });

    let id: number = 0;
    this.cylindersevice.getAllCenters().subscribe(data => {
      console.log(data);
      this.centers = data;

      this.activatedRoute.params.subscribe(data => {
        id = data.id;
        this.cylindersevice.getCylinder(id).subscribe(response => {
          console.log(response);
          this.cylinder = response;
  
        });
        
      });
    });
   
  }

  
  get cylindertype(){
    return this.updatecylinder.get('type');
  }
  // get center(){
  //   return this.updatecylinder.get('center');
  // }
  get qunatity(){
    return this.updatecylinder.get('quantity');
  }
  
  get weight(){
    return this.updatecylinder.get('weight');
  }
  get price(){
    return this.updatecylinder.get('pricePerCylinder');
  }
  
    
  onUpdate() {
    

    let centerName: string = "center1";
    console.log(centerName);
    this.centers.forEach(center => {
      if(center.centerName === centerName) {
        this.cylinder.center.centerId = center.centerId;
      }
    });
   
    console.log(this.cylinder);
    this.cylindersevice.updateCylinder(this.cylinder).subscribe(data => {
      console.log('response',data);
      if(data) {
        this.success = true;
        alert("Cylinder updated successfully");
      this.route.navigateByUrl("/viewcylinder");
       // this.message = "Medicine updated successfully";
        
      }
      else {
        this.success = false;
        //this.message = "Problem updating data";
        alert("Problem on updating data");
      }
      //this.router.navigateByUrl("/products/viewAll");
      this.route.navigateByUrl("/viewcylinder");

    })

}
}
