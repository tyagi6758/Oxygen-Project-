import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Center } from "../center";

@Injectable({
  providedIn: 'root'
})
export class CenterService {
 

  constructor(private _httpClient: HttpClient) { }

  getCategory(centerId: number): Observable<Center> {
    let url = "http://localhost:9090/center/"+centerId;
    return this._httpClient.get<Center>(url).pipe(map(response => response));
  }
  addcenter(center:Center): Observable<Center> {
    let url = "http://localhost:9090/center/";
    return this._httpClient.post<Center>(url, center);
  }
  getAllCenters(): Observable<Center[]> {
    let url = "http://localhost:9090/center/";
    return this._httpClient.get<Center[]>(url).pipe(map(response => response));
  }
  updateCenter(center: Center): Observable<Center> {
    let url = "http://localhost:9090/center/";
    console.log(url);
    return this._httpClient.put<Center>(url, center);   
     
  }

  deleteCenter(centerId: number): Observable<boolean> {
    let url = "http://localhost:9090/center/"+centerId;
    console.log(url);
    let returnVal: Observable<boolean> =  this._httpClient.delete<boolean>(url);  
    return returnVal; 
}

}
