import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';


@Component({
  selector: 'app-viewcylinderbycity',
  templateUrl: './viewcylinderbycity.component.html',
  styleUrls: ['./viewcylinderbycity.component.css']
})
export class ViewcylinderbycityComponent implements OnInit {

  title="view cylinder";
public viewcylinderbycityForm:FormGroup;

msg:string='';
success:boolean=false;
redirect:boolean=false;
  constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit() :void {
    this.viewcylinderbycityForm=new FormGroup({
      // city: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      
    });
  }

  addingcylinder(){
    console.warn(this.viewcylinderbycityForm.value);
  }  
  // get city(){
  //   return this.viewcylinderbycityForm.get('city');
  // }
 
  
  onSubmit() {
    this.route.navigate(["/ordercylinder"]);
  


}
}
