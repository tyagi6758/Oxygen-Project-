import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdercylinderComponent } from './ordercylinder.component';

describe('OrdercylinderComponent', () => {
  let component: OrdercylinderComponent;
  let fixture: ComponentFixture<OrdercylinderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrdercylinderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdercylinderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
